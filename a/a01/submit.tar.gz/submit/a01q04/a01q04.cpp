// File: a01q04.cpp
// Name: Brysen Landis

#include <iostream>

int main()
{
    std::cout << '"' << "Prediction is very difficult,\n"
              << "especially about the future." << '"' << '\n'
              << "    Niels Bohr\n"
              << "    Danish physicist (1885 - 1962)\n"
              << "\n";

    return 0;
}
