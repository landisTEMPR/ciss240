// File: a01q03.cpp
// Name: Brysen Landis

#include <iostream>

int main()
{
    std::cout << " d   4      3\n"
              << "-- 3x  = 12x\n"
              << "dx\n"
              << "\n";

    return 0;
}
