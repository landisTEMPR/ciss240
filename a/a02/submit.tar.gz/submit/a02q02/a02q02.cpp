// File: a02q02.cpp
// Name: Brysen Landis

#include <iostream>

int main()
{
    int x;
    
    std::cout << "How old are you? ";
    std::cin >> x;
    std::cout << "You are " << x << " years old now. Next year you will be " << x + 1 << '.' << std::endl;

    return 0;
}
