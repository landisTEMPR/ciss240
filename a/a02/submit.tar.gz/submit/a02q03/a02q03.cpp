// File: a02q03.cpp
// Name: Brysen Landis

#include <iostream>

int main()
{
    int x, y, z, i, t;

    std::cin >> x >> y >> z >> i >> t;
    std::cout << x + (y / (z + i)) * ( t * t * t) << std::endl;

    return 0;

}



