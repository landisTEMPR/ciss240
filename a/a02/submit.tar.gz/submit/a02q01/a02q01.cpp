// File: a02q01
// Name: Brysen Landis

#include <iostream>

int main()
{
    int w, h, f;

    std::cout << "Enter w: ";
    std::cin >> w;
    std::cout << "Enter h: ";
    std::cin >> h;
    std::cout << "Enter f: ";
    std::cin >> f;

    std::cout << "IQ: " << 3 * w / h + (3 + f) / 42 << std::endl;
    
    

    return 0;
}
